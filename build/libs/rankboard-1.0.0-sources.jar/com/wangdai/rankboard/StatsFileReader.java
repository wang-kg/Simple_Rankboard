package com.wangdai.rankboard;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5218;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

final class StatsFileReader {
    private static final Gson GSON = new Gson();

    private static final String STATS = "stats";
    private static final String MINED = "minecraft:mined";
    private static final String USED = "minecraft:used";
    private static final String CUSTOM = "minecraft:custom";
    private static final String DEATHS = "minecraft:deaths";

    private final MinecraftServer server;

    StatsFileReader(MinecraftServer server) {
        this.server = server;
    }

    List<PlayerStatsSnapshot> readAll() {
        Path statsDir = server.method_27050(class_5218.field_24181);
        if (!Files.isDirectory(statsDir)) {
            return List.of();
        }

        List<PlayerStatsSnapshot> snapshots = new ArrayList<>();
        try (Stream<Path> files = Files.list(statsDir)) {
            files.filter(path -> path.getFileName().toString().endsWith(".json"))
                    .forEach(path -> read(path).ifPresent(snapshots::add));
        } catch (IOException e) {
            RankBoardMod.LOGGER.warn("Failed to list player stats in {}", statsDir, e);
        }
        RankBoardMod.LOGGER.info("RankBoard loaded {} player stats from {}", snapshots.size(), statsDir);
        return snapshots;
    }

    private Optional<PlayerStatsSnapshot> read(Path path) {
        try (Reader reader = Files.newBufferedReader(path)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null || !root.has(STATS) || !root.get(STATS).isJsonObject()) {
                return Optional.empty();
            }

            JsonObject stats = root.getAsJsonObject(STATS);
            String name = resolveName(path);
            long placed = sumPlacedBlocks(stats.getAsJsonObject(USED));
            long mined = sumValues(stats.getAsJsonObject(MINED));
            long moved = sumMovementMeters(stats.getAsJsonObject(CUSTOM));
            long deaths = getLong(stats.getAsJsonObject(CUSTOM), DEATHS);
            return Optional.of(new PlayerStatsSnapshot(name, placed, mined, moved, deaths));
        } catch (IOException | RuntimeException e) {
            RankBoardMod.LOGGER.warn("Failed to read stats file {}", path, e);
            return Optional.empty();
        }
    }

    private String resolveName(Path path) {
        String fileName = path.getFileName().toString();
        String uuidText = fileName.substring(0, fileName.length() - ".json".length());
        try {
            UUID uuid = UUID.fromString(uuidText);
            for (var player : server.method_3760().method_14571()) {
                if (player.method_5667().equals(uuid)) {
                    return player.method_7334().name();
                }
            }
            var profile = server.method_73550().comp_4407().method_14512(uuid);
            if (profile.isPresent()) {
                return profile.get().comp_4423();
            }
        } catch (IllegalArgumentException ignored) {
            return uuidText;
        }
        return uuidText.substring(0, Math.min(8, uuidText.length()));
    }

    private static long sumPlacedBlocks(JsonObject usedStats) {
        if (usedStats == null) {
            return 0L;
        }

        long total = 0L;
        for (var entry : usedStats.entrySet()) {
            class_2960 id = parseId(entry.getKey());
            if (id == null) {
                continue;
            }

            class_1792 item = class_7923.field_41178.method_63535(id);
            if (item instanceof class_1747) {
                total += asLong(entry.getValue());
            }
        }
        return total;
    }

    private static long sumMovementMeters(JsonObject customStats) {
        if (customStats == null) {
            return 0L;
        }

        long centimeters = 0L;
        for (var entry : customStats.entrySet()) {
            if (entry.getKey().endsWith("_one_cm")) {
                centimeters += asLong(entry.getValue());
            }
        }
        return centimeters / 100L;
    }

    private static long sumValues(JsonObject object) {
        if (object == null) {
            return 0L;
        }

        long total = 0L;
        for (JsonElement value : object.asMap().values()) {
            total += asLong(value);
        }
        return total;
    }

    private static long getLong(JsonObject object, String key) {
        if (object == null || !object.has(key)) {
            return 0L;
        }
        return asLong(object.get(key));
    }

    private static long asLong(JsonElement element) {
        if (element == null || !element.isJsonPrimitive()) {
            return 0L;
        }
        try {
            return element.getAsLong();
        } catch (RuntimeException ignored) {
            return 0L;
        }
    }

    private static class_2960 parseId(String id) {
        return class_2960.method_12829(id);
    }
}
