package com.wangdai.rankboard;

import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_274;
import net.minecraft.class_2995;
import net.minecraft.class_8646;
import net.minecraft.class_9014;
import net.minecraft.class_9015;
import net.minecraft.class_9020;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;

final class SidebarRenderer {
    private static final String OBJECTIVE = "rankboard";

    private final MinecraftServer server;

    SidebarRenderer(MinecraftServer server) {
        this.server = server;
    }

    void render(BoardPage page, List<PlayerRank> ranks, RankBoardConfig config) {
        List<String> lines = createLines(page, ranks, config);
        class_2995 scoreboard = server.method_3845();

        class_266 oldObjective = scoreboard.method_1170(OBJECTIVE);
        if (oldObjective != null) {
            scoreboard.method_1194(oldObjective);
        }

        class_266 objective = scoreboard.method_1168(
                OBJECTIVE,
                class_274.field_1468,
                class_2561.method_43470(formatTitle(page, config)),
                class_274.class_275.field_1472,
                false,
                class_9020.field_47557
        );

        int score = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            class_9015 holder = class_9015.method_55422("rb_" + i);
            class_9014 access = scoreboard.method_1180(holder, objective);
            access.method_55410(score--);
            access.method_55411(class_2561.method_43470(lines.get(i)));
            access.method_55412(class_9020.field_47557);
        }

        scoreboard.method_1158(class_8646.field_45157, objective);
    }

    void clear() {
        class_2995 scoreboard = server.method_3845();
        class_266 objective = scoreboard.method_1170(OBJECTIVE);
        if (objective != null) {
            scoreboard.method_1158(class_8646.field_45157, null);
            scoreboard.method_1194(objective);
        }
    }

    private static List<String> createLines(BoardPage page, List<PlayerRank> ranks, RankBoardConfig config) {
        List<String> lines = new ArrayList<>();
        if (ranks.isEmpty()) {
            lines.add(config.emptyText);
            return lines;
        }

        for (int i = 0; i < ranks.size(); i++) {
            PlayerRank rank = ranks.get(i);
            String value = NumberFormatter.format(rank.value(), page.unit(), config.compactNumbers);
            lines.add(applyTemplate(config.nameTemplate, page, i + 1, trim(rank.name(), 24), value, config));
            lines.add(applyTemplate(config.valueTemplate, page, i + 1, trim(rank.name(), 24), value, config));
        }
        return lines;
    }

    private static String formatTitle(BoardPage page, RankBoardConfig config) {
        return applyTemplate(config.titleTemplate, page, 0, "", "", config);
    }

    private static String applyTemplate(String template, BoardPage page, int rank, String name, String value, RankBoardConfig config) {
        return template
                .replace("{title}", config.titleFor(page))
                .replace("{page}", Integer.toString(page.pageNumber()))
                .replace("{pages}", Integer.toString(BoardPage.pageCount()))
                .replace("{rank}", Integer.toString(rank))
                .replace("{name}", name)
                .replace("{value}", value);
    }

    private static String trim(String text, int maxLength) {
        if (text.length() <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength - 1) + ".";
    }
}
