package com.wangdai.rankboard;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

final class RankBoardCommands {
    private RankBoardCommands() {
    }

    static void register(RankBoardMod mod) {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(method_9247("rankboard")
                        .requires(class_2170.method_71774(class_2170.field_31839))
                        .then(method_9247("reload").executes(context -> {
                            mod.manager().reload();
                            feedback(context.getSource(), "RankBoard 配置已重载。");
                            return 1;
                        }))
                        .then(method_9247("refresh").executes(context -> {
                            mod.manager().refresh();
                            feedback(context.getSource(), "RankBoard 数据已刷新。");
                            return 1;
                        }))
                        .then(method_9247("next").executes(context -> {
                            mod.manager().nextPage();
                            feedback(context.getSource(), "RankBoard 已切换到下一页。");
                            return 1;
                        }))
                        .then(method_9247("show")
                                .then(method_9244("page", StringArgumentType.word())
                                        .suggests((context, builder) -> {
                                            builder.suggest("placed");
                                            builder.suggest("mined");
                                            builder.suggest("moved");
                                            builder.suggest("deaths");
                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            String pageId = StringArgumentType.getString(context, "page");
                                            BoardPage page = BoardPage.byId(pageId);
                                            if (page == null) {
                                                feedback(context.getSource(), "未知页面，可用：placed, mined, moved, deaths");
                                                return 0;
                                            }
                                            mod.manager().show(page);
                                            feedback(context.getSource(), "RankBoard 已切换到 " + page.title() + "。");
                                            return 1;
                                        })))
                        .then(method_9247("status").executes(context -> {
                            RankBoardConfig config = mod.manager().config();
                            feedback(context.getSource(), "RankBoard: 每页 " + config.entriesPerPage
                                    + " 名，轮播 " + config.pageSeconds
                                    + " 秒，刷新 " + config.refreshSeconds + " 秒。");
                            return 1;
                        }))));
    }

    private static void feedback(class_2168 source, String message) {
        source.method_9226(() -> class_2561.method_43470(message), false);
    }
}
